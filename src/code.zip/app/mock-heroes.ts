import { Hero } from './hero';

export const HEROES: Hero[] = [
  { id: 11, name: 'Dr Nice', age:'20', date:'11/11/11', gender:'M'},
  { id: 12, name: 'Narco', age:'20', date:'11/11/11', gender:'M' },
  { id: 13, name: 'Bombasto', age:'20', date:'11/11/11', gender:'M' },
  { id: 14, name: 'Celeritas', age:'20', date:'11/11/11', gender:'M' },
  { id: 15, name: 'Magneta', age:'20', date:'11/11/11', gender:'M' }
];