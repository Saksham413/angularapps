export interface Hero {
    id: number;
    name: string;
    age: string;
    date: string;
    gender: string;
  }